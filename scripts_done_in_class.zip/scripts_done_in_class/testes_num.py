import numpy as np
aleatorio = np.eye(3)
print(aleatorio)
print(aleatorio.std())